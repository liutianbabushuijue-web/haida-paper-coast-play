# 追潮记 V16 — asset credits

## Kenney Nature Kit

Source: https://kenney.nl/assets/nature-kit

License: CC0 1.0. Original license is retained at `references/kenney-nature/pack/License.txt`.

Meshes used in this version: grass, grass_leafs, stone_largeC, stone_smallC, stone_smallFlatA, stone_smallFlatB. Adapted in Blender with new paper materials, curved leaves, small edge bevels, and custom placement. These are included in `paper-coast.glb`.

## Polyfork reef crab

Source: https://polyfork.dev/asset/reef-crab-base?edition=hd

Author: Polyfork. License: CC BY 4.0 https://creativecommons.org/licenses/by/4.0/

V15 Blender derivative retained at `/coast-v15/reef-crab-paper.glb`. V16 changes size, shell colors, behavior, hand presentation and discovery integration. The character is stylized and is not an identification model of a particular crab species. Gold coloration is a fictional collectible variant.

## Tidewater

Source: https://github.com/dgreenheck/tidewater

MIT, copyright (c) 2026 DRG Software Solutions LLC. Existing inherited boat/audio/water contributions retain their earlier credit files. V16 studied the bend/twist approach in `src/world/vegetation/PlantGeometry.js` for inspiration; its vegetation system and scanned debris were not imported wholesale. Our new wind shader is in `nature-motion.js`.

## Considered, not included

KayKit Forest: https://kaylousberg.itch.io/kaykit-forest — reviewed as a potential source. No KayKit assets are included in this version.

The island base and its paper materials derive from the project's existing approved Blender scene. The three large tide-pool boulders remain the approved V7 pool asset.
