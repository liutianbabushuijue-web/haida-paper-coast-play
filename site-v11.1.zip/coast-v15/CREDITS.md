Reef crab by Polyfork
https://polyfork.dev/asset/reef-crab-base?edition=hd
Redistributed under CC BY 4.0: https://creativecommons.org/licenses/by/4.0/
Original preserved; V15 derivative modifies palette and mesh finish in Blender. Cartoon character, no species identification claimed.
