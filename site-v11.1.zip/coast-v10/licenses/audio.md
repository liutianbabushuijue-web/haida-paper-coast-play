# V10 选定音效

用户于 2026-11-16 选择：A/B/C 随机用于鱼抛入水中，D 用于沙地落鱼，E 不采用。持鱼和普通游泳无拟音。

- A — 轻拨水面，Whiplaff，CC0。来源：https://freesound.org/people/Whiplaff/sounds/273223/
- B — 短促泼水，Braleven，CC0。来源：https://freesound.org/people/Braleven/sounds/319418/
- C — 小水花，morganveilleux，CC0。来源：https://freesound.org/people/morganveilleux/sounds/390005/
- D — 沙地翻身，adviseme333，CC0。来源：https://freesound.org/people/adviseme333/sounds/679389/

来源保留原件；试听副本匹配峰值，运行时截取短动作、淡入淡出并做距离衰减。旧版本素材许可另保存在 coast-v9/licenses。
