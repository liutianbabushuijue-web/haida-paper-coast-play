# V13 音频来源与触发说明

原创合成：catch_ultra（五阶 D 大调五声音阶，150 BPM）、fish_escape。生成脚本 scripts/render-v13-sound.py；未复制 Balatro 录音。

沿用已选 catch B/A/C、water A/B/C、sand D；翻页 A 不接入。

本轮接入 CC0 录音（使用前轮已下载的试听剪辑）：
- 01_reel_wind · Spinning reel.wav · https://freesound.org/people/tosha73/sounds/509902/ · CC0 1.0
- 02_reel_drag · Angel Fly Fish Reel Fast Pull_1.wav · https://freesound.org/people/paulprit/sounds/507070/ · CC0 1.0
- 03_line_strain · nylon rope string fishing line handling tying tie tense friction · https://freesound.org/people/kyles/sounds/450849/ · CC0 1.0
- 05_page_b · Page Turn · https://freesound.org/people/sokworks/sounds/860360/ · CC0 1.0
- 06_stamp · Stamp · https://freesound.org/people/kermite607/sounds/362624/ · CC0 1.0
- 07_paper_tear · Paper Tear · https://freesound.org/people/RealSquink/sounds/787409/ · CC0 1.0
- 08_book_close · Book Close - 16 · https://freesound.org/people/SpaceJoe/sounds/484896/ · CC0 1.0
- 09_wade · Wading in Shallow Water.wav · https://freesound.org/people/ryansitz/sounds/342932/ · CC0 1.0

wade_step.mp3 是 wade 剪辑的前 0.42 秒并加淡入淡出。所有来源明细保留于 references/audio-round2-20261117/manifest.json。
资源只用于本地 V13；没有更新公开站点。